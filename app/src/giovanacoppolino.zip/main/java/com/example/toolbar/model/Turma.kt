package com.example.toolbar.model

data class Turma(
    val id: Int,
    val curso: String
)
