package com.example.toolbar.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.toolbar.R

class ListagemAlunoItem : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listagem_aluno_item)
    }
}