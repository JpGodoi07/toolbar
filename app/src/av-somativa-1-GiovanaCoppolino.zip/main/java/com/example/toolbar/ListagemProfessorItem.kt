package com.example.toolbar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ListagemProfessorItem : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listagem_professor_item)
    }
}