package com.example.toolbar

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.example.toolbar.databinding.ActivityCadalunosBinding


class cadalunos : AppCompatActivity() {

    private val binding by lazy {
        ActivityCadalunosBinding.inflate(layoutInflater)
    }

    //Gestão da Galeria do Celular
    private val gestaoGaleria = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ){ uri ->
        if ( uri != null){
            binding.imgPerfil.setImageURI( uri )
            Toast.makeText(this,
                "Imagem Selecionada",
                Toast.LENGTH_SHORT).show()
        }else{
            Toast.makeText(this,
                "Nenhuma Imagem Selecionada",
                Toast.LENGTH_SHORT).show()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        acessarGaleria()
    }


    private fun acessarGaleria() {
        binding.btnGaleria.setOnClickListener {
            gestaoGaleria.launch("image/*")
        }
    }

    //Criando o menu_principal da tela do App
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_principal, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        //testando a ação de clique
        when(item.itemId){
            R.id.menu_home -> {
                Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show()
                val intent = Intent (this, MainActivity::class.java)
                startActivity(intent)
            }


            R.id.menu_alunos -> {
                Toast.makeText(this, "Alunos", Toast.LENGTH_SHORT).show()
                val intent = Intent (this, ListagemAluno::class.java)
                startActivity(intent)
            }

            R.id.menu_professores -> {
                Toast.makeText(this, "Professores", Toast.LENGTH_SHORT).show()
                val intent = Intent (this, ListagemProfessor::class.java)
                startActivity(intent)
            }

            R.id.menu_turmas -> {
                Toast.makeText(this, "Turmas", Toast.LENGTH_SHORT).show()
                val intent = Intent (this,ListagemTurma::class.java)
                startActivity(intent)
            }

            R.id.menu_sair -> {
                Toast.makeText(this, "Sair", Toast.LENGTH_SHORT).show()
                val intent = Intent (this, MainActivity::class.java)
                startActivity(intent)
            }

        }

        return true
    }
}